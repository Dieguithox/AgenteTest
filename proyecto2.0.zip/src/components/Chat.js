import React, { useLayoutEffect, useRef, useEffect } from "react";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import SendIcon from "@mui/icons-material/Send";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import InputBase from "@mui/material/InputBase";
import Divider from "@mui/material/Divider";
import Alert from "@mui/material/Alert";
import CircularProgress from "@mui/material/CircularProgress";
import Button from "@mui/material/Button";
import Grow from "@mui/material/Grow";
import Fade from "@mui/material/Fade";
import { v4 as uuidv4 } from "uuid";
import InsightsOutlinedIcon from "@mui/icons-material/InsightsOutlined";
import QuestionAnswerOutlinedIcon from "@mui/icons-material/QuestionAnswerOutlined";
import PsychologyRoundedIcon from "@mui/icons-material/PsychologyRounded";
import TableRowsRoundedIcon from "@mui/icons-material/TableRowsRounded";
import AnswerDetailsDialog from "./AnswerDetailsDialog.js";
import { alpha } from "@mui/material/styles";
import { WELCOME_MESSAGE, MAX_LENGTH_INPUT_SEARCH } from "../env";
import MyChart from "./MyChart.js";
import Answering from "./Answering.js";
import QueryResultsDisplay from "./QueryResultsDisplay";
import {
  invokeBedrockAgent,
  getQueryResults,
  generateChart,
} from "../utils/AwsCalls";
import {
  extractFirstMarkdownTable,
  markdownTableToHtml,
  copyHtmlToClipboard,
} from "../utils/Utils.js";
import MarkdownRenderer from "./MarkdownRenderer.js";

const STORAGE_KEY = "mtc_chat_state";

const handleCopyTableHtml = async (markdownTable) => {
  if (!markdownTable) return;
  const html = markdownTableToHtml(markdownTable);
  await copyHtmlToClipboard(html);
};

function loadInitialChatState() {
  const empty = {
    answers: [],
    controlAnswers: [],
    totalAnswers: 0,
    sessionId: uuidv4(),
  };

  if (typeof window === "undefined") return empty;

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return empty;

    const parsed = JSON.parse(raw);

    return {
      answers: Array.isArray(parsed.answers) ? parsed.answers : [],
      controlAnswers: Array.isArray(parsed.controlAnswers)
        ? parsed.controlAnswers
        : [],
      totalAnswers:
        typeof parsed.totalAnswers === "number" ? parsed.totalAnswers : 0,
      sessionId:
        typeof parsed.sessionId === "string" && parsed.sessionId.length > 0
          ? parsed.sessionId
          : uuidv4(),
    };
  } catch (e) {
    console.error("Error leyendo estado inicial del chat", e);
    return empty;
  }
}

const Chat = ({ userName = "Guest User", clearChatToken }) => {
  // ---- estado principal con restauración desde localStorage ----
  const initialState = loadInitialChatState();

  const [totalAnswers, setTotalAnswers] = React.useState(
    initialState.totalAnswers
  );
  const [enabled, setEnabled] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [controlAnswers, setControlAnswers] = React.useState(
    initialState.controlAnswers
  );
  const [answers, setAnswers] = React.useState(initialState.answers);
  const [query, setQuery] = React.useState("");
  const [sessionId, setSessionId] = React.useState(initialState.sessionId);
  const [errorMessage, setErrorMessage] = React.useState("");
  const [height, setHeight] = React.useState(480);
  const [openAnswerDetails, setOpenAnswerDetails] = React.useState(false);
  const [size, setSize] = React.useState([0, 0]);
  const [selectedAB, setSelectedAB] = React.useState(0);

  const borderRadius = 8;

  const scrollRef = useRef(null);

  // Persistir en localStorage cada vez que cambie el estado del chat
  useEffect(() => {
    try {
      const stateToSave = {
        answers,
        controlAnswers,
        totalAnswers,
        sessionId,
      };
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(stateToSave));
    } catch (e) {
      console.error("Error guardando estado del chat", e);
    }
  }, [answers, controlAnswers, totalAnswers, sessionId]);

  // Limpiar chat cuando cambie el token que viene de LayoutApp
  useEffect(() => {
    if (!clearChatToken) return; // al inicio es 0, no hace nada

    setAnswers([]);
    setControlAnswers([]);
    setTotalAnswers(0);
    try {
      window.localStorage.removeItem(STORAGE_KEY);
    } catch (e) {
      console.error("Error limpiando estado del chat", e);
    }
  }, [clearChatToken]);

  // scroll automático al final
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [answers]);

  useLayoutEffect(() => {
    function updateSize() {
      setSize([window.innerWidth, window.innerHeight]);
      const myh = window.innerHeight - 220;
      if (myh < 346) {
        setHeight(346);
      } else {
        setHeight(myh);
      }
    }
    window.addEventListener("resize", updateSize);
    updateSize();
    return () => window.removeEventListener("resize", updateSize);
  }, []);

  const effectRan = React.useRef(false);
  useEffect(() => {
    if (!effectRan.current) {
      console.log("effect applied - only on the FIRST mount");
      const fetchData = async () => {
        console.log("Chat");
      };
      fetchData().catch(console.error);
    }
    return () => (effectRan.current = true);
  }, []);

  const handleQuery = (event) => {
    if (event.target.value.length > 0 && loading === false && query !== "")
      setEnabled(true);
    else setEnabled(false);
    setQuery(event.target.value.replace("\n", ""));
  };

  const handleKeyPress = (event) => {
    if (event.code === "Enter" && loading === false && query !== "") {
      getAnswer(query);
    }
  };

  const handleClick = async (e) => {
    e.preventDefault();
    if (query !== "") {
      getAnswer(query);
    }
  };

  const getAnswer = async (my_query) => {
    if (!loading && my_query !== "") {
      setControlAnswers((prevState) => [...prevState, {}]);
      setAnswers((prevState) => [...prevState, { query: my_query }]);
      setEnabled(false);
      setLoading(true);
      setErrorMessage("");
      setQuery("");

      try {
        const queryUuid = uuidv4();
        const {
          completion,
          usage,
          totalInputTokens,
          totalOutputTokens,
          runningTraces,
          countRationals,
        } = await invokeBedrockAgent(
          sessionId,
          my_query,
          setAnswers,
          setControlAnswers,
          userName,
          queryUuid
        );

        let json = {
          text: completion,
          usage,
          totalInputTokens,
          totalOutputTokens,
          runningTraces,
          queryUuid,
          countRationals,
        };

        const queryResults = await getQueryResults(queryUuid);
        console.log(queryResults);
        if (queryResults.length > 0) {
          json.chart = "loading";
          json.queryResults = queryResults;
        }

        console.log(json);

        // Update the final answer with complete data
        setAnswers((prevState) => {
          const newState = [...prevState];
          for (let i = newState.length - 1; i >= 0; i--) {
            if (newState[i].isStreaming) {
              newState[i] = json;
              break;
            }
          }
          return newState;
        });

        setLoading(false);
        setEnabled(false);

        if (queryResults.length > 0) {
          json.chart = await generateChart(json);
          console.log("--------- Answer after chart generation ------");
          console.log(json);

          // Update again with chart data
          setAnswers((prevState) => {
            const newState = [...prevState];
            for (let i = newState.length - 1; i >= 0; i--) {
              if (newState[i].queryUuid === queryUuid) {
                newState[i] = json;
                break;
              }
            }
            return newState;
          });

          setTotalAnswers((prevState) => prevState + 1);
        } else {
          console.log("------- Answer without chart-------");
          console.log(json);
          setTotalAnswers((prevState) => prevState + 1);
        }
      } catch (error) {
        console.log("Call failed: ", error);
        setErrorMessage(error.toString());
        setLoading(false);
        setEnabled(false);

        // Update the streaming answer with error state
        setAnswers((prevState) => {
          const newState = [...prevState];
          for (let i = newState.length - 1; i >= 0; i--) {
            if (newState[i].isStreaming) {
              newState[i] = {
                ...newState[i],
                text: "Error occurred while getting response",
                isStreaming: false,
                error: true,
              };
              break;
            }
          }
          return newState;
        });
      }
    }
  };

  const handleCloseAnswerDetails = () => {
    setOpenAnswerDetails(false);
  };

  const handleClickOpenAnswerDetails = (value) => () => {
    setSelectedAB(value);
    setOpenAnswerDetails(true);
  };

  const handleShowTab = (index, type) => () => {
    const updatedItems = [...controlAnswers];
    updatedItems[index] = { ...updatedItems[index], current_tab_view: type };
    setControlAnswers(updatedItems);
  };

  return (
    <Box sx={{ pl: 2, pr: 2, pt: 0, pb: 0 }}>
      {errorMessage !== "" && (
        <Alert
          severity="error"
          sx={{
            position: "fixed",
            width: "80%",
            top: "65px",
            left: "20%",
            marginLeft: "-10%",
          }}
          onClose={() => {
            setErrorMessage("");
          }}
        >
          {errorMessage}
        </Alert>
      )}

      <Box
        id="chatHelper"
        sx={{
          display: "flex",
          flexDirection: "column",
          height: height,
          overflow: "hidden",
          overflowY: "scroll",
        }}
      >
        {answers.length > 0 ? (
          <ul style={{ paddingBottom: 14, margin: 0, listStyleType: "none" }}>
            {answers.map((answer, index) => {
              // 🔍 Detectar primera tabla Markdown en la respuesta
              const tableMd =
                answer && typeof answer.text === "string"
                  ? extractFirstMarkdownTable(answer.text)
                  : null;

              // pequeño guard para evitar errores si aún no hay controlAnswers[index]
              const control = controlAnswers[index] || {};
              const currentTab = control.current_tab_view || "answer";

              return (
                <li key={"meg" + index} style={{ marginBottom: 0 }}>
                  {answer.hasOwnProperty("text") ? (
                    <Box
                      sx={{
                        borderRadius: borderRadius,
                        pl: 1,
                        pr: 1,
                        display: "flex",
                        alignItems: "flex-start",
                        marginBottom: 1,
                      }}
                    >
                      <Box sx={{ pr: 1, pt: 1.5, pl: 0.5 }}>
                        <img
                          src="/images/genai.png"
                          alt="Amazon Bedrock"
                          width={28}
                          height={28}
                        />
                      </Box>
                      <Box sx={{ p: 0, flex: 1 }}>
                        <Box>
                          {/* 🧩 Pestaña Respuesta */}
                          <Grow
                            in={currentTab === "answer"}
                            timeout={{ enter: 600, exit: 0 }}
                            style={{ transformOrigin: "50% 0 0" }}
                            mountOnEnter
                            unmountOnExit
                          >
                            <Box
                              id={"answer" + index}
                              sx={{
                                opacity: 0.8,
                                "&.MuiBox-root": {
                                  animation: "fadeIn 0.8s ease-in-out forwards",
                                },
                                mt: 1,
                              }}
                            >
                              {/* 🔘 Botón copiar tabla como HTML (solo si hay tabla) */}
                              {tableMd && (
                                <Box
                                  sx={{
                                    display: "flex",
                                    justifyContent: "flex-end",
                                    mb: 1,
                                  }}
                                >
                                  <Button
                                    size="small"
                                    variant="outlined"
                                    onClick={() => handleCopyTableHtml(tableMd)}
                                  >
                                    Copiar tabla
                                  </Button>
                                </Box>
                              )}

                              <Typography component="div" variant="body1">
                                <MarkdownRenderer content={answer.text} />
                              </Typography>
                            </Box>
                          </Grow>

                          {/* 🧩 Pestaña Registros */}
                          {answer.hasOwnProperty("queryResults") && (
                            <Grow
                              in={currentTab === "records"}
                              timeout={{ enter: 600, exit: 0 }}
                              style={{ transformOrigin: "50% 0 0" }}
                              mountOnEnter
                              unmountOnExit
                            >
                              <Box
                                sx={{
                                  opacity: 0.8,
                                  "&.MuiBox-root": {
                                    animation: "fadeIn 0.8s ease-in-out forwards",
                                  },
                                  transform: "translateY(10px)",
                                  "&.MuiBox-root-appear": {
                                    transform: "translateY(0)",
                                  },
                                  mt: 1,
                                }}
                              >
                                <QueryResultsDisplay index={index} answer={answer} />
                              </Box>
                            </Grow>
                          )}

                          {/* 🧩 Pestaña Gráfica */}
                          {answer.hasOwnProperty("chart") &&
                            typeof answer.chart === "object" &&
                            answer.chart.hasOwnProperty("chart_type") && (
                              <Grow
                                in={currentTab === "chart"}
                                timeout={{ enter: 600, exit: 0 }}
                                style={{ transformOrigin: "50% 0 0" }}
                                mountOnEnter
                                unmountOnExit
                              >
                                <Box
                                  sx={{
                                    opacity: 0.8,
                                    "&.MuiBox-root": {
                                      animation: "fadeIn 0.9s.ease-in-out.forwards",
                                    },
                                    transform: "translateY(10px)",
                                    "&.MuiBox-root-appear": {
                                      transform: "translateY(0)",
                                    },
                                    mt: 1,
                                  }}
                                >
                                  <MyChart
                                    caption={answer.chart.caption}
                                    options={answer.chart.chart_configuration.options}
                                    series={answer.chart.chart_configuration.series}
                                    type={answer.chart.chart_type}
                                  />
                                </Box>
                              </Grow>
                            )}
                        </Box>

                        {/* 🔘 Zona de botones Respuesta / Registros / Gráfica */}
                        {answer.hasOwnProperty("queryResults") && (
                          <Box
                            sx={{
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "flex-start",
                              gap: 1,
                              py: 1,
                              mt: 1,
                            }}
                          >
                            <Button
                              color="secondary"
                              onClick={handleClickOpenAnswerDetails(index)}
                              startIcon={<PsychologyRoundedIcon />}
                            >
                              Detalles
                            </Button>

                            {answer.queryResults.length > 0 && (
                              <Fade
                                timeout={1000}
                                in={answer.queryResults.length > 0}
                              >
                                <Box
                                  sx={{ display: "flex", alignItems: "center" }}
                                >
                                  <Button
                                    sx={(theme) => ({
                                      pr: 1,
                                      pl: 1,
                                      "&.Mui-disabled": {
                                        borderBottom: 0.5,
                                        color: theme.palette.primary.main,
                                        borderRadius: 0,
                                      },
                                    })}
                                    data-amplify-analytics-on="click"
                                    data-amplify-analytics-name="click"
                                    data-amplify-analytics-attrs="button:answer-details"
                                    size="small"
                                    color="secondaryText"
                                    disabled={currentTab === "answer"}
                                    onClick={handleShowTab(index, "answer")}
                                    startIcon={<QuestionAnswerOutlinedIcon />}
                                  >
                                    Respuesta
                                  </Button>

                                  <Button
                                    sx={(theme) => ({
                                      pr: 1,
                                      pl: 1,
                                      "&.Mui-disabled": {
                                        borderBottom: 0.5,
                                        color: theme.palette.primary.main,
                                        borderRadius: 0,
                                      },
                                    })}
                                    data-amplify-analytics-on="click"
                                    data-amplify-analytics-name="click"
                                    data-amplify-analytics-attrs="button:answer-details"
                                    size="small"
                                    color="secondaryText"
                                    disabled={currentTab === "records"}
                                    onClick={handleShowTab(index, "records")}
                                    startIcon={<TableRowsRoundedIcon />}
                                  >
                                    Registros
                                  </Button>

                                  {typeof answer.chart === "object" &&
                                    answer.chart.hasOwnProperty("chart_type") && (
                                      <Button
                                        sx={(theme) => ({
                                          pr: 1,
                                          pl: 1,
                                          "&.Mui-disabled": {
                                            borderBottom: 0.5,
                                            color: theme.palette.primary.main,
                                            borderRadius: 0,
                                          },
                                        })}
                                        data-amplify-analytics-on="click"
                                        data-amplify-analytics-name="click"
                                        data-amplify-analytics-attrs="button:answer-details"
                                        size="small"
                                        color="secondaryText"
                                        disabled={currentTab === "chart"}
                                        onClick={handleShowTab(index, "chart")}
                                        startIcon={<InsightsOutlinedIcon />}
                                      >
                                        Gráfica
                                      </Button>
                                    )}
                                </Box>
                              </Fade>
                            )}

                            {answer.chart === "loading" && (
                              <Box
                                sx={{
                                  display: "flex",
                                  alignItems: "center",
                                  ml: 1,
                                }}
                              >
                                <CircularProgress size={16} color="primary" />
                                <Typography
                                  variant="caption"
                                  color="secondaryText"
                                  sx={{ ml: 1 }}
                                >
                                  Generando gráfico...
                                </Typography>
                              </Box>
                            )}

                            {answer.chart &&
                              typeof answer.chart === "object" &&
                              answer.chart.hasOwnProperty("rationale") && (
                                <Typography variant="caption" color="secondaryText">
                                  {answer.chart.rationale}
                                </Typography>
                              )}
                          </Box>
                        )}
                      </Box>
                    </Box>
                  ) : answer.hasOwnProperty("rationaleText") ? (
                    <Grid container justifyContent="flex-start">
                      <Fade timeout={2000} in={true}>
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            mb: 1,
                            pl: 2,
                            py: 1,
                          }}
                        >
                          <Box sx={{ display: "flex", alignItems: "center" }}>
                            <img
                              src="/images/sun.256x256.png"
                              width={22}
                              height={22}
                              style={{ opacity: 0.4 }}
                            />
                          </Box>

                          <Box
                            sx={{
                              pl: 0.5,
                              pr: 2,
                              ml: 1,
                              display: "flex",
                              alignItems: "center",
                              flexGrow: 1,
                            }}
                          >
                            <Typography color="text.secondary" variant="body1">
                              {answer.rationaleText}
                            </Typography>
                          </Box>
                        </Box>
                      </Fade>
                    </Grid>
                  ) : (
                    <Grid container justifyContent="flex-end">
                      <Box
                        sx={(theme) => ({
                          textAlign: "right",
                          borderRadius: borderRadius,
                          fontWeight: 500,
                          py: 1,
                          px: 2,
                          mt: 2,
                          mb: 1.5,
                          mr: 1,
                          boxShadow: "rgba(0, 0, 0, 0.05) 0px 4px 12px",
                          border: `1px solid ${alpha(theme.palette.primary.main, 0.25)}`,
                          backgroundColor: alpha(
                            theme.palette.primary.main,
                            0.08
                          ),
                        })}
                      >
                        <Typography
                          sx={{
                            color: "text.primary",
                            fontSize: "0.95rem",
                            fontWeight: 500,
                          }}
                        >
                          {answer.query}
                        </Typography>
                      </Box>
                    </Grid>
                  )}
                </li>
              );
            })}

            {loading && (
              <Box sx={{ p: 0, pl: 1, mb: 2, mt: 1 }}>
                <Answering loading={loading} />
              </Box>
            )}

            {/* this is the last item that scrolls into view when the effect is run */}
            <li ref={scrollRef} />
          </ul>
        ) : (
          <Box
            sx={{
              height: height,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              px: 3,
            }}
          >
            <Box sx={{ textAlign: "center", maxWidth: 600 }}>
              <Box sx={{ mb: 4 }}>
                <img
                  src="/images/amazon_bedrock_agents.png"
                  alt="Agentes MTCenter"
                  height={96}
                  style={{ opacity: 0.9 }}
                />
              </Box>

              <Typography
                variant="h4"
                sx={{
                  fontWeight: 600,
                  fontSize: { xs: "1.75rem", sm: "2rem" },
                  lineHeight: 1.2,
                  mb: 2,
                  color: "text.primary",
                  letterSpacing: "-0.02em",
                }}
              >
                {/*Agents for Amazon Bedrock*/}
              </Typography>

              <Typography
                variant="body1"
                sx={{
                  color: "text.secondary",
                  fontSize: "1.1rem",
                  lineHeight: 1.5,
                  mb: 3,
                  fontWeight: 400,
                }}
              >
                {/*Servicio totalmente gestionado que permite a las aplicaciones de IA generativa
                ejecutar tareas empresariales de varios pasos utilizando lenguaje natural.*/}
              </Typography>

              <Box
                sx={(theme) => ({
                  borderRadius: 2,
                  px: 3,
                  py: 2,
                  border: `1px solid ${alpha(
                    theme.palette.primary.main,
                    0.18
                  )}`,
                  backgroundColor: alpha(theme.palette.primary.light, 0.08),
                })}
              >
                <Typography
                  variant="body1"
                  sx={{
                    color: "secondary.main",
                    fontWeight: 500,
                    lineHeight: 1.4,
                  }}
                >
                  {WELCOME_MESSAGE}
                </Typography>
              </Box>
            </Box>
          </Box>
        )}
      </Box>

      <Paper
        component="form"
        sx={(theme) => ({
          zIndex: 0,
          p: 1,
          mb: 2,
          display: "flex",
          alignItems: "center",
          boxShadow:
            "rgba(20, 40, 60, 0.06) 0px 4px 16px, rgba(20, 40, 60, 0.04) 0px 8px 24px, rgba(20, 40, 60, 0.03) 0px 16px 56px",
          borderRadius: 6,
          position: "relative",
          // Remove the default border
          border: "none",
          // Add gradient border using pseudo-element
          "&::before": {
            content: '""',
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            borderRadius: 6,
            padding: "1px", // This creates the border thickness
            background: `linear-gradient(to right, 
                    ${theme.palette.divider}, 
                    ${alpha(theme.palette.primary.main, 0.3)}, 
                    ${theme.palette.divider})`,
            mask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
            maskComposite: "xor",
            WebkitMask:
              "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
            WebkitMaskComposite: "xor",
            zIndex: -1,
          },
        })}
      >
        <Box sx={{ pt: 1.5, pl: 0.5 }}>
          <img
            src="/images/AWS_logo_RGB.png"
            alt="Amazon Web Services"
            height={20}
          />
        </Box>
        <InputBase
          required
          id="query"
          name="query"
          placeholder="Escriba su pregunta..."
          fullWidth
          multiline
          onChange={handleQuery}
          onKeyDown={handleKeyPress}
          value={query}
          variant="outlined"
          inputProps={{ maxLength: MAX_LENGTH_INPUT_SEARCH }}
          sx={{ pl: 1, pr: 2 }}
        />
        <Divider sx={{ height: 32 }} orientation="vertical" />
        <IconButton
          color="primary"
          sx={{ p: 1 }}
          aria-label="directions"
          disabled={!enabled}
          onClick={handleClick}
        >
          <SendIcon />
        </IconButton>
      </Paper>

      {selectedAB > 0 && (
        <AnswerDetailsDialog
          open={openAnswerDetails}
          handleClose={handleCloseAnswerDetails}
          answer={answers[selectedAB]}
          question={
            answers[selectedAB - (answers[selectedAB].countRationals + 1)].query
          }
        />
      )}
    </Box>
  );
};

export default Chat;