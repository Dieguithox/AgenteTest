// ================================
// CUSTOMIZABLE CONFIGURATION VALUES
// ================================

// AWS Configuration - UPDATE THESE VALUES
const AWS_REGION = "us-east-1"; // Your AWS region
const AGENT_ID = "SPB0NJP1YN"; // Your Bedrock Agent ID //ROL=amplify-amplifyvideogamessal-dev-96dd2-authRole
const AGENT_ALIAS_ID = "MVCLJUATPX"; // Your Bedrock Agent Alias ID
const QUESTION_ANSWERS_TABLE_NAME = "mtc_query_results"; // Your DynamoDB table name

// Application Information - CUSTOMIZE AS NEEDED
const APP_NAME = "Asistente de Área Comercial";
const APP_SUBJECT = "Consultas de área comercial";
const WELCOME_MESSAGE = "Soy tu asistente personal del área comercial";

// ================================
// SYSTEM CONFIGURATION
// ================================

const MAX_LENGTH_INPUT_SEARCH = 200; // Caracteres disponibles en la consulta
const MODEL_ID_FOR_CHART = "us.anthropic.claude-3-7-sonnet-20250219-v1:0";

const CHART_PROMPT = `
Crea configuraciones detalladas de ApexCharts.js basadas en la información proporcionada para apoyar la respuesta. 
Tu objetivo es producir una sola gráfica útil, con análisis y visual profesional.

===================================
📥 INPUT DATA
===================================
<information>
    <summary>
        <<answer>>
    </summary>
    <data_sources>
        <<data_sources>>
    </data_sources>
</information>

===================================
📤 FORMATO DE SALIDA OBLIGATORIO
===================================

Si generas gráfica:

<has_chart>1</has_chart>
<chart_type>[bar|line|pie]</chart_type>
<chart_configuration>{JSON_VALIDO}</chart_configuration>
<caption>Texto breve (20-40 palabras) describiendo la gráfica</caption>

Si NO generas gráfica:

<has_chart>0</has_chart>
<rationale>Motivo breve (máx. 12 palabras)</rationale>

======================================
📌 REGLAS CRÍTICAS — JSON VÁLIDO
======================================

⚠️ Estas reglas son obligatorias.  
⚠️ Si no las cumples, la interfaz fallará.  
⚠️ NO uses sintaxis de JavaScript. SOLO JSON puro.

1) **NO usar expresiones de JavaScript**
   - ❌ Array(30).fill(...)
   - ❌ funciones dentro de JSON (excepto strings static code)
   - ❌ new Date()
   - ❌ undefined, NaN, Infinity
   - ❌ Comentarios // o /* */

2) **chart_configuration DEBE ser JSON puro**
   Ejemplo válido:
   {
     "series": [
       { "name": "Ventas", "data": [10, 20, 30] }
     ],
     "options": {
       "chart": { "type": "bar" },
       "xaxis": { "categories": ["Ene","Feb","Mar"] }
     }
   }

   NO incluyas comas finales.

3) **Formateadores (formatter)**
   - Solo como STRING, NO como función.
   - Ejemplo correcto:
     "formatter": "currency_mxn"
   - El front interpretará ese string.
   - Para montos en MXN usa SIEMPRE el literal:
     "formatter": "currency_mxn"
   - El frontend se encargará de convertir "currency_mxn" en una función JavaScript real.
   - No uses Array(30).fill, new Date ni otras expresiones JS dentro del JSON.

4) **Tipos numéricos**
   - Montos deben ser NÚMEROS, no strings.
   - ❌ "$123,000"
   - ✔ 123000

5) **Series consistentes**
   - En cada serie, "data" debe ser solo números o solo objetos.
   - No mezclar:
     ❌ [100, {x: "ene", y: 200}]
     ✔ [{"x":"ene", "y":100}, {"x":"feb","y":200}]

6) **Pie charts**
   Deben seguir esta estructura:
   {
     "series": [30.2, 15.8, 54.0],
     "options": {
       "chart": { "type": "pie" },
       "labels": ["A","B","C"]
     }
   }

7) **Line y Bar charts**
   Estructura válida:
   {
     "series": [
       { "name":"Ventas", "data":[100,200,300] }
     ],
     "options": {
       "chart": { "type":"line" },
       "xaxis": { "categories":["2025-10-01","2025-10-02"] }
     }
   }

8) **No repetir keys, no dejar campos vacíos**
   - No dejar "data":[] si la serie no tiene sentido.
   - Siempre incluir títulos mínimos: title.text, xaxis.title, yaxis.title.

======================================
📌 LINEAMIENTOS VISUALES
======================================

- Gráficas limpias, legibles y profesionales.
- Usar colores estándar de ApexCharts.
- "height": 420 o 450.
- Textos alineados al centro cuando aplique.
- Modo claro (light).

======================================
📌 EJEMPLOS BASE (VALIDADOS)
======================================

<ChartExamples>
  <Chart description="Line Ejemplo">
    <type>line</type>
    <configuration>
{
  "series": [
    { "name": "Desktops", "data": [10,41,35,51,49,62,69,91,148] }
  ],
  "options": {
    "chart": { "height": 420, "type": "line", "zoom": { "enabled": false } },
    "dataLabels": { "enabled": false },
    "stroke": { "curve": "straight" },
    "title": { "text": "Tendencia", "align": "center" },
    "grid": { "row": { "colors": ["#f3f3f3", "transparent"], "opacity": 0.5 } },
    "xaxis": { "categories": ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep"] }
  }
}
    </configuration>
  </Chart>

  <Chart description="Pie Ejemplo">
    <type>pie</type>
    <configuration>
{
  "series": [2077,1036.75,384.99,277.49],
  "options": {
    "chart": {"type":"pie","height":420},
    "labels":["North America","Europe","Other Regions","Japan"],
    "title":{"text":"Distribución","align":"center"},
    "legend":{"position":"bottom"},
    "colors":["#008FFB","#00E396","#FEB019","#FF4560"]
  }
}
    </configuration>
  </Chart>
</ChartExamples>

======================================
📌 IDIOMA
======================================
- Toda la salida debe ser en español.
======================================

`;

export {
  // AWS Configuration
  AWS_REGION,
  AGENT_ID,
  AGENT_ALIAS_ID,
  QUESTION_ANSWERS_TABLE_NAME,

  // Application Information
  APP_NAME,
  APP_SUBJECT,
  WELCOME_MESSAGE,

  // System Configuration
  MAX_LENGTH_INPUT_SEARCH,
  MODEL_ID_FOR_CHART,
  CHART_PROMPT,
};